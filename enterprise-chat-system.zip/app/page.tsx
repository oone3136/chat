'use client';

import { useChat } from '@/hooks/useChat';
import { AuthBox } from '@/components/auth/AuthBox';
import { ChatArea } from '@/components/chat/ChatArea';
import { ConnectionStatus } from '@/components/common/ConnectionStatus';

export default function Page() {
  const { state, register, login, sendMessage, logout } = useChat();

  return (
    <div className="h-screen flex flex-col bg-background">
      {/* Connection Status */}
      <ConnectionStatus
        isConnected={state.isConnected}
        isAuthenticated={state.isAuthenticated}
        currentUser={state.currentUser}
        userCabang={state.userCabang}
        userDivisi={state.userDivisi}
        onLogout={logout}
      />

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden w-full">
        {!state.isAuthenticated ? (
          <AuthBox
            onRegister={register}
            onLogin={login}
            isLoading={state.isLoading}
            error={state.error}
          />
        ) : (
          <ChatArea
            messages={state.messages}
            currentUser={state.currentUser}
            onSendMessage={sendMessage}
            isAuthenticated={state.isAuthenticated}
          />
        )}
      </div>
    </div>
  );
}
