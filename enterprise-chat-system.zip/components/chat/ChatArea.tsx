'use client';

import { MessageList } from './MessageList';
import { MessageInput } from './MessageInput';
import { ChatMessage } from '@/hooks/useChat';

interface ChatAreaProps {
  messages: ChatMessage[];
  currentUser: string;
  onSendMessage: (message: string, type: 'PUBLIC' | 'PRIVATE' | 'DIVISI' | 'CABANG', to?: string) => void;
  isAuthenticated: boolean;
}

export function ChatArea({
  messages,
  currentUser,
  onSendMessage,
  isAuthenticated,
}: ChatAreaProps) {
  return (
    <div className="flex flex-col h-full bg-background">
      <MessageList messages={messages} currentUser={currentUser} />
      {isAuthenticated && <MessageInput onSendMessage={onSendMessage} isDisabled={false} />}
    </div>
  );
}
