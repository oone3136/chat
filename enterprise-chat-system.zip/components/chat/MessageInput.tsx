'use client';

import { useState } from 'react';
import { Send, Lock, Users, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MessageInputProps {
  onSendMessage: (message: string, type: 'PUBLIC' | 'PRIVATE' | 'DIVISI' | 'CABANG', to?: string) => void;
  isDisabled: boolean;
}

export function MessageInput({ onSendMessage, isDisabled }: MessageInputProps) {
  const [message, setMessage] = useState('');
  const [type, setType] = useState<'PUBLIC' | 'PRIVATE' | 'DIVISI' | 'CABANG'>('PUBLIC');
  const [toUser, setToUser] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      onSendMessage(message.trim(), type, type === 'PRIVATE' ? toUser : undefined);
      setMessage('');
      setToUser('');
    }
  };

  const messageTypes = [
    { value: 'PUBLIC' as const, label: 'Publik', icon: Globe, color: 'text-green-500' },
    { value: 'PRIVATE' as const, label: 'Private', icon: Lock, color: 'text-purple-500' },
    { value: 'DIVISI' as const, label: 'Divisi', icon: Users, color: 'text-blue-500' },
    { value: 'CABANG' as const, label: 'Cabang', icon: Users, color: 'text-cyan-500' },
  ];

  return (
    <form onSubmit={handleSend} className="bg-secondary border-t border-border p-4 space-y-3">
      {/* Message Type Selector */}
      <div className="flex gap-2 flex-wrap">
        {messageTypes.map(({ value, label, icon: Icon, color }) => (
          <button
            key={value}
            type="button"
            onClick={() => setType(value)}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
              type === value
                ? 'bg-primary text-white'
                : 'bg-background text-muted-foreground hover:text-foreground border border-border'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {/* Private Message Recipient */}
      {type === 'PRIVATE' && (
        <div>
          <input
            type="text"
            value={toUser}
            onChange={(e) => setToUser(e.target.value)}
            placeholder="Username penerima"
            className="w-full px-3 py-2 rounded-lg bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm"
            disabled={isDisabled}
          />
        </div>
      )}

      {/* Message Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Tulis pesan Anda..."
          className="flex-1 px-4 py-2 rounded-lg bg-background border border-input text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
          disabled={isDisabled}
        />
        <Button
          type="submit"
          disabled={isDisabled || !message.trim()}
          className="bg-primary hover:bg-primary/90 text-white px-4"
        >
          <Send className="w-4 h-4" />
          <span className="hidden sm:inline ml-2">Kirim</span>
        </Button>
      </div>
    </form>
  );
}
